---
name: esp32-development
description: ESP32 development with PlatformIO — setup, board-specific quirks, BLE, WiFi, build troubleshooting
---

# ESP32 Development

PlatformIO-based ESP32 development, covering setup, board-specific quirks, and common pitfalls.

## PlatformIO Setup (macOS + Nix)

**Nix PlatformIO is BROKEN** — the built-in `uv` tries to pip-install `tool-esptoolpy` into the immutable Nix Python store, triggering PEP 668 errors. The workaround:

```bash
# Clean venv with Python 3.11+
python3.11 -m venv ~/.pio_venv
~/.pio_venv/bin/pip install platformio esptool
```

Use `~/.pio_venv/bin/pio` for everything. The system `pio` from Nix must NOT be used.

### Builder Patch

The espressif32 platform builder sets `OBJCOPY='esptool'` and `UPLOADER='esptool'` in `~/.platformio/platforms/espressif32@*/builder/main.py`. Patch these to the venv path:

```python
# OBJCOPY:
OBJCOPY='/Users/<user>/.pio_venv/bin/esptool',
# UPLOADER:
UPLOADER="/Users/<user>/.pio_venv/bin/esptool",
```

Also fix `--before` / `--after` separator style for esptool v5 (underscores → dashes):
- `default_reset` → `default-reset`
- `hard_reset` → `hard-reset`

## Board-Specific Quirks

### ESP32-C3 Super Mini
- **CPU**: RISC-V single-core 160MHz, **400KB SRAM** (tight!)
- **LED**: GPIO8, **active LOW** (`digitalWrite(8, LOW)` = on)
- **BOOT button**: GPIO9
- **Serial**: Native USB CDC (`/dev/cu.usbmodem101`), **not** CH340/UART

### ESP32-C3 Serial Access Problem
Opening `/dev/cu.usbmodem101` toggles DTR/RTS, which resets the C3 into **download mode** (`boot:0x7`). The chip then waits for esptool and never runs the firmware.

**Solutions**:
1. **Read serial during upload**: Open the port while `pio run -t upload` is still running (right after "Hard resetting via RTS pin"). The upload process holds DTR/RTS correctly.
2. **Verify via MQTT**: If the firmware publishes to MQTT, subscribe to the broker instead of reading serial.
3. **Use a UART bridge**: Wire a CH340/CP2102 to the C3's UART0 pins (GPIO20/21) for reliable serial access.

### ESP32-C3 BLE + WiFi RAM Constraint
**CRITICAL**: The C3 has only 400KB RAM. BLE (Bluedroid/NimBLE) + WiFi simultaneously exhausts heap and causes silent crashes ("Guru Meditation Error: Core 0 panic'ed").

**Fix**: Initialize BLE **before** WiFi, connect to BMS/peripheral, THEN start WiFi+MQTT:

```cpp
void setup() {
  // 1. BLE first
  BLEDevice::init("device-name");
  // connect to peripheral...
  
  // 2. WiFi/MQTT after BLE connect
  WiFi.begin(ssid, pass);
  mqtt.connect(broker);
}
```

Expected free heap on C3:
- Before BLE: ~250KB
- After BLE init: ~80KB
- After WiFi + BLE: ~30KB

## BLE BMS Bridge Patterns

### BMS Protocol Detection
Not all BMS brands use the same BLE service:
- **JBD / Xiaoxiang / Overkill**: Nordic UART Service (NUS) — `6e400001-b5a3-f393-e0a9-e50e24dcca9e`
- **JK BMS / BDRG**: Service `0xFFE0` / characteristic `0xFFE1`

### BDRG BMS Specifics
- Device name format: `R-<model>-<serial>` (e.g. `R-12100BNNH19-C01278`)
- Uses JK protocol (0xFFE0), **not** JBD/NUS
- Manufacturer data contains MAC: `[0x585A]` payload = 6-byte MAC

### JK BMS Protocol (0xFFE0)
- Service UUID: `0000ffe0-0000-1000-8000-00805f9b34fb`
- Characteristic: `0000ffe1-0000-1000-8000-00805f9b34fb` (notify)
- Device sends notification frames periodically (no request needed):
  - Frame header: `0x55 0xAA` or `0xAA 0x55`
  - Record type `0x01`: basic info (voltage, current, SOC, temps)
  - Record type `0x02`: cell voltages
  - Record type `0x03`: status/error flags
  - CRC16 (Modbus) at end

### JBD Protocol (NUS)
- Service: `6e400001-b5a3-f393-e0a9-e50e24dcca9e`
- TX: `6e400002-b5a3-f393-e0a9-e50e24dcca9e` (write)
- RX: `6e400003-b5a3-f393-e0a9-e50e24dcca9e` (notify)
- Request: `DD A5 <cmd> 00 <checksum>`
- Response: `DD 5A <cmd> <len> <data...> <checksum>`
- Checksum: sum of all bytes, not XOR

## Partition Tables

For firmware >1.3MB (common with BLE+WiFi+JSON), use `huge_app`:
```ini
board_build.partitions = huge_app.csv
```
Gives 3MB for app partition (address `0x10000`). Fits in 4MB flash.

## Pitfalls

1. **Don't use Nix PlatformIO** — always use a pip venv with Python 3.11+
2. **ESP32-C3 can't run BLE+WiFi simultaneously** — init BLE first, WiFi after
3. **C3 native USB Serial resets chip on open** — use upload-time reading or MQTT for debug
4. **C3 Super Mini LED is active LOW on GPIO8** — `digitalWrite(8, LOW)` = on
5. **BDRG BMS is JK protocol, not JBD** — check Service UUID before implementing
6. **esptool v5 uses dashes in flags** (`default-reset`), not underscores like v4
7. **C3 BLE double-init crash**: Calling `BLEDevice::init()` twice (main + BMS class) crashes C3. Init once globally.
8. **MQTT retained false positive**: `connected` with `retain=true` persists after crash. Use non-retained heartbeat for liveness.
9. **C3 Serial via upload window**: Read serial WHILE `pio run -t upload` runs (after "Hard resetting via RTS pin"). Standalone open always gives `boot:0x7` download mode.
