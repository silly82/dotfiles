---
name: dreamhost-shared-hosting
description: Use when deploying to Dreamhost shared hosting.
version: 1.0.0
---

# Dreamhost Shared Hosting

Use when deploying code, setting up cron, or debugging SSH/Apache on Silvan's Dreamhost shared account (pdx1-shared-a1-13). Sites: bristenblick.ch, anathol.ch, figaro-der-frisurenladen.ch (+ mehrere Alt-Projekte im selben Home).

## SSH Access

- User `silly82`, host = domain (z.B. `silly82@bristenblick.ch`).
- Dedicated key: `~/.ssh/hermes_dreamhost` (ed25519, no passphrase). Pubkey lives in server `~/.ssh/authorized_keys`.
- ALWAYS pass `-o IdentitiesOnly=yes -o IdentityFile=~/.ssh/hermes_dreamhost -o BatchMode=yes -o PasswordAuthentication=no`. Without `IdentitiesOnly` the server disconnects with "Too many authentication failures" (agent has multiple keys; server gives up after a few offers).
- If `~/.ssh/authorized_keys` does not exist on the server: `mkdir -p ~/.ssh && chmod 700 ~/.ssh` first, then append, then `chmod 600 ~/.ssh/authorized_keys`.
- **Server is flaky**: commands randomly time out (banner exchange, mid-session hangs). Retry pattern: `sleep 5–15`, retry with `-o ConnectTimeout=10`. Retrying works — do not conclude the host is down.

## Webroot layout & Apache permissions

- Each domain = `~/domain.tld/`. Subsites = subdirs (e.g. `~/bristenblick.ch/timelapse/`).
- Root `.htaccess` may rewrite ALL requests into a default subdir (bristenblick.ch → `/weather/`). A new subdir MUST be excluded or it 404s/redirects: add `RewriteCond %{REQUEST_URI} !^/<subdir>/` alongside the existing conditions.
- After rsync/scp/mv, files often land as 600/700 → Apache answers **403 Forbidden**. Fix: `chmod 755` dirs, `chmod 644` files (`chmod -R u=rwX,go=rX .`). Also remove `.DS_Store`.
- Verify every deploy with curl: HTTP 200 on `index.html`, one JS/CSS asset, and one data file.

## rsync deploy pitfalls (hard-won, cost us the data dir once)

1. **Never `~` in rsync DEST** — rsync expands `~` on the LOCAL side (`mkdir /Users/you/... failed`). Use a path relative to the remote home: `DEST=bristenblick.ch/timelapse/`.
2. **Never `--delete` on a sync whose target also holds server-side data** (`data/`, logs, uploads). One `--delete` run wiped archive+thumbs+manifest+status. Split into separate syncs per top-level dir; only use `--delete` on pure-code targets (e.g. `scripts/` → `scripts/`), never on the docroot when `data/` lives there too.
3. Keep `data/` out of git (`.gitignore`) AND out of deploy syncs — it is server-state, not code.

## Cron on Dreamhost

- Panel-created jobs live in the managed `###--- BEGIN DREAMHOST BLOCK` section of the user crontab. **Replacing the whole crontab via `crontab -` silently deletes the other jobs** (we killed the bitzi watchdog once). Always: `crontab -l` → save full output → edit offline → push complete file back. Panel edits to the managed block get overwritten by the panel itself.
- Cron invokes commands via `sh` (dash), not bash. Inside `sh -c '...'` (single quotes) **`$HOME` is NOT expanded** — the crontab line must use the absolute path `/home/silly82/...`.
- Scripts must be POSIX: `#!/bin/sh`, no `pipefail`, no bashisms. Verify with `dash -n script.sh` locally.
- **`~/logs` is owned by `dhapache` and NOT writable by the user** — redirecting there hangs/fails the job. Log into the project dir instead (`mkdir -p data/logs` in the runner script, `>> data/logs/webcam.log 2>&1`).
- Enable the panel's "Use locking" (setlock) to prevent overlapping runs.
- Runner-script pattern: resolve own dir portably (`SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd); cd "$SCRIPT_DIR/.."`), then call the python steps.

## Python on the server

- Server: python3 3.10 (`/usr/bin/python3`). Mac system python3: 3.9. Code must run on BOTH:
  - No `X | None` union annotations (3.10+ only).
  - `datetime.fromisoformat` on 3.9 rejects many strings — use `datetime.strptime(s, "%Y-%m-%dT%H-%M-%SZ")`.
- `pip install --user pillow` works and includes WebP support on the server (`PIL.features.check("webp") == True`).

## Static frontend in a subdirectory

If the site is served under `/subdir/`, ALL asset/fetch paths must be relative (`css/site.css`, `js/app.js`, `data/manifest.json`) — absolute paths (`/js/...`, `/data/...`) resolve against the domain root and 404. This bit twice in one session (data fetches AND static assets). Write relative from the start; grep for `(src|href)="/` before deploying.

## Session detail

- `references/sillywebcamview-deploy-2026-07.md` — full error transcripts, working crontab template (bitzi + timelapse jobs), .htaccess example, flaky-SSH retry log.
